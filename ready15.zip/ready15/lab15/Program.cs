using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Rewrite;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
.AddCookie(options =>
{
    options.LoginPath = "/login";
    options.AccessDeniedPath = "/accessdenied";
});
builder.Services.AddAuthorization();

var app = builder.Build();

var options = new RewriteOptions()
    .AddRedirect("(.*)/$", "$1")
    .AddRewrite("(?i)home", "home", skipRemainingRules: false)
    .AddRewrite("(?i)admin", "admin", skipRemainingRules: false)
    .AddRewrite("(?i)user", "user", skipRemainingRules: false);
app.UseRewriter(options);

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/home", [Authorize]() => "HomePage");

app.Map("/admin", [Authorize(Roles = "admin")] () => "Hello, Admin");

app.Map("/user", [Authorize(Roles = "user")] () => "Hello, User");

app.MapGet("/login", () => "Please, Log in");

app.MapGet("/accessdenied", async (HttpContext context) =>
{
    context.Response.StatusCode = 403;
    await context.Response.WriteAsync("Access Denied");
});

app.MapGet("/", async (HttpContext context) =>
{
    context.Response.ContentType = "text/html; charset=utf-8";
    string loginForm = @"<!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8' />
        <title>lab15</title>
    </head>
    <body>
        <h2>Login Form</h2>
        <form method='post'>
            <p>
                <label>Login</label><br />
                <input name='login' />
            </p>
            <p>
                <label>Password</label><br />
                <input type='password' name='password' />
            </p>
            <input type='submit' value='Login' />
        </form>
    </body>
    </html>";
    await context.Response.WriteAsync(loginForm);
});

app.MapPost("/", async (string? returnUrl, HttpContext context) =>
{
    var form = context.Request.Form;
    string login = form["login"];
    string password = form["password"];

    Person? person = DbContext.Persons.FirstOrDefault(p => p.Login == login && p.Password == password);
    if (person is null) return Results.Unauthorized();
    var claims = new List<Claim>
    {
        new Claim(ClaimsIdentity.DefaultNameClaimType, person.Login),
        new Claim(ClaimsIdentity.DefaultRoleClaimType, person.Role.Name)
    };
    var claimsIdentity = new ClaimsIdentity(claims, "Cookies");
    var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
    await context.SignInAsync(claimsPrincipal);
    return Results.Redirect(returnUrl ?? "/home");
});


app.Run();

public static class DbContext
{
    static readonly Role admin = new Role("admin");
    static readonly Role user = new Role("user");

    static public List<Person> Persons =
    [
        new Person("Dasha", "123", admin),
            new Person("Slava", "321", user)
    ];

}
public class Person
{
    public string Login { get; set; }
    public string Password { get; set; }
    public Role Role { get; set; }

    public Person(string login, string pass, Role role)
    {
        Login = login;
        Password = pass;
        Role = role;
    }

}

public class Role
{
    public string Name { get; set; }
    public Role(string name)
    {
        Name = name;
    }
}
