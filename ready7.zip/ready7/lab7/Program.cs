var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

var loggerFactory = LoggerFactory.Create(builder => builder.AddDebug());
ILogger logger = loggerFactory.CreateLogger<Program>();

app.MapGet("/", () =>
{
    logger.LogWarning("Some info");
    return "Hello World!";
});

app.Run();
