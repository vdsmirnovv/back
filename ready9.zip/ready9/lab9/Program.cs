var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.UseStatusCodePages("text/plain", "Error: Resource Not Found. Status code: {0}");

app.Environment.EnvironmentName = "Production";

if (app.Environment.IsProduction())
{
    app.UseExceptionHandler(app => app.Run(async context =>
    {
        context.Response.StatusCode = 500;
        await context.Response.WriteAsync("Error 500. DivideByZeroException occurred!");
    }));
}

app.Map("/", () =>
{
    int a = 10;
    int b = 1;
    int c = a / b;
    return $"c = {c}";
});

app.Run();
