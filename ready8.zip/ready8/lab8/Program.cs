var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();

var app = builder.Build();

app.UseSession();

app.Run(async (context) =>
{
    context.Session.SetString("Name", "Vadim");
    context.Session.SetString("Age", "21");
    context.Session.SetString("Date", "13.05.2024");

    context.Response.Cookies.Append("Name", "Vadim");
    context.Response.Cookies.Append("University", "Moscow Polytech University");

    await context.Response.WriteAsync($"Sessions\n\n");

    foreach ( var i in context.Session.Keys)
    {
        await context.Response.WriteAsync($"{i}: {context.Session.GetString(i)}\n");
    }

    await context.Response.WriteAsync($"\nCookies\n\n");

    string? name = context.Request.Cookies["Name"];
    string? uni = context.Request.Cookies["University"];
    await context.Response.WriteAsync($"{name}, {uni}");
   
});

app.Run();
