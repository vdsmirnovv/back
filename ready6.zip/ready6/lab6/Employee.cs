﻿namespace lab6
{
    public class Employee
    {
        public string Name { get; set; }
        public string Company { get; set; }
    }
}
