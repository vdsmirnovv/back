﻿using lab13.Models;

namespace lab13.services
{
    public class PLantService
    {
        List<Plant> plants = new List<Plant>
        {
            new Plant("Алое", null , 800, null, null),
            new Plant("Кактус", "perfect", 900, null, null),
            new Plant("Базилик", null, 1000, null, null)
        };
         
        public async Task<List<Plant>> GetAllPlants() 
        {
            return plants;
        }
    }
}
