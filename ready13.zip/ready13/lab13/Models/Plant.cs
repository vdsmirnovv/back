﻿namespace lab13.Models
{
    public class Plant
    {
        public Plant(string name, string? description, decimal price, string? family, string? genus)
        {
            Id = Guid.NewGuid();
            Name = name;
            Description = description;
            Price = price;
            Family = family;
            Genus = genus;
        }
        public Guid Id { get; }

        public string Name { get; } = null!;

        public string? Description { get; }

        public decimal Price { get; }

        public string? Family { get; }

        public string? Genus { get; }
    }
}
