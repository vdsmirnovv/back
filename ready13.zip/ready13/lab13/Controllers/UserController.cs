﻿using lab13.Contracts;
using lab13.Models;
using lab13.services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace lab13.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class UserController : ControllerBase
    {
        [HttpPost("/Register")]
        public async Task<IResult> Register(RegisterUserRequest request, UserService userService)
        {
            await userService.Register(request.UserName, request.Email, request.Password);
            return Results.Ok("User registered");
        }

        [HttpPost("/Login")]
        public async Task<IResult> Login(LoginUserRequest request, UserService userService)
        {
            var context = HttpContext;

            var user = await userService.Login(request.Email, request.Password);

            var claims = new List<Claim>
            {
                new Claim(ClaimsIdentity.DefaultNameClaimType, user.Email),
                new Claim(ClaimsIdentity.DefaultRoleClaimType, user.Role.Name)
            };

            var claimsIdentity = new ClaimsIdentity(claims, "Cookies");
            var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

            await context.SignInAsync(claimsPrincipal);

            return Results.Ok(user);
        }

        [HttpGet]
        public async Task<IResult> GetUsers(UserService userService)
        {
            var users = userService.GetUsers();
            return Results.Ok(users);
        }

        [HttpPost]
        public async Task<IResult> CreateUser(UserService userService, CreateUserRequest request)
        {
            var user = userService.CreateUser(request.UserName, request.Email, request.Password, request.Role);
            return Results.Ok(user);
        }
    }
}
