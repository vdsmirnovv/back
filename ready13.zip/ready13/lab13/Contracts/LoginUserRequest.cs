﻿using System.ComponentModel.DataAnnotations;

namespace lab13.Contracts
{
    public record LoginUserRequest(
        [Required] string Email,
        [Required] string Password);
}
