﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;

namespace lab17
{
    public class PlantService
    {
        private readonly DbPlantContext _db;
        private readonly IMemoryCache _cache;
        public PlantService(DbPlantContext db, IMemoryCache cache)
        {
            _db = db;
            _cache = cache;
        }

        public string GetPlant(int id)
        {
            _cache.TryGetValue(id, out Plant? plant);
            if (plant != null) return plant.ToString() + " (from MemoryCache)";
            plant = _db.Plants.FirstOrDefault(p => p.ID == id);
            if (plant != null)
            {
                _cache.Set(id, plant, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(5)));
                return plant.ToString() + " (from DataBase)";
            }
            return "NotFound";

        }
    }
}
