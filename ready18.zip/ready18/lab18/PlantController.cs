﻿using App.Metrics;
using lab17;
using Microsoft.AspNetCore.Mvc;

namespace lab18
{
    [ApiController]
    public class PlantController : ControllerBase
    {
        private readonly PlantService _plantService;
        private readonly IMetrics _metrics;
        public PlantController( PlantService service, IMetrics metrics)
        {
            _plantService = service;
            _metrics = metrics;
        }

        [HttpGet("plant/{id}")]
        public string GetPlantId(string id)
        {
            _metrics.Measure.Counter.Increment(AppMetrics.CounterCallGetPlant);
            return _plantService.GetPlant(int.Parse(id));
        }
    }
}
